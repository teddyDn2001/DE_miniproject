from kafka import KafkaProducer
import json
import time
import random

producer = KafkaProducer(
    bootstrap_servers='localhost:9093',
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

# Tạo dữ liệu user giả lập
def generate_user():
    names = ["Jun", "Linh", "An", "Huy", "Tú"]
    return {
        "name": random.choice(names),
        "age": random.randint(10, 30),
        "email": f"user{random.randint(1,100)}@example.com"
    }

while True:
    user = generate_user()
    print("Sending:", user)
    producer.send('user_topic', user)
    time.sleep(2)
