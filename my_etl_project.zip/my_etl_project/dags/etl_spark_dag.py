from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime

default_args = {
    'start_date': datetime(2025, 4, 24),
    'catchup': False
}

dag = DAG(
    dag_id='spark_etl_pipeline',
    schedule_interval='@hourly',
    default_args=default_args
)

run_spark_job = BashOperator(
    task_id='run_spark_etl',
    bash_command='/opt/bitnami/spark/bin/spark-submit /opt/bitnami/spark_app/etl_job.py',
    dag=dag
)
